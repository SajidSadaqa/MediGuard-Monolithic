﻿using System;
using System.Threading.Tasks;

namespace MediGuard.API.Helpers
{
    public static class DummyPaymentProcessor
    {
        /// <summary>
        /// Simulates processing a payment.
        /// </summary>
        /// <param name="amount">The amount to charge.</param>
        /// <param name="paymentMethod">The payment method identifier.</param>
        /// <returns>A Task that returns true if the payment is processed successfully; otherwise, false.</returns>
        public static async Task<bool> ProcessPaymentAsync(decimal amount, string paymentMethod)
        {
            // Simulate processing delay
            await Task.Delay(500);

            // Dummy logic:
            // If the amount is greater than zero and a payment method is provided, consider it a successful transaction.
            if (amount <= 0 || string.IsNullOrWhiteSpace(paymentMethod))
            {
                return false;
            }

            // Further processing or logging can be added here if necessary

            return true;
        }
    }
}
