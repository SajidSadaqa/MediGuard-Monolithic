﻿using System.Collections.Generic;
using System.Linq;

namespace MediGuard.API.Helpers
{
    public static class ConflictChecker
    {
        /// <summary>
        /// Checks for potential medication conflicts based on given medication names.
        /// </summary>
        /// <param name="medications">A list of medication names.</param>
        /// <returns>True if a conflict is detected; otherwise, false.</returns>
        public static bool HasConflict(List<string> medications)
        {
            if (medications == null || medications.Count < 2)
                return false;

            // Example rule: A conflict is detected if both "Warfarin" and "Aspirin" are present.
            if (medications.Contains("Warfarin") && medications.Contains("Aspirin"))
                return true;

            // Additional conflict rules can be added here

            return false;
        }
    }
}
